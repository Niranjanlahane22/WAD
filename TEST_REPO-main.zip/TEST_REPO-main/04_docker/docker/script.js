let u_string;
let myMap = new Map([[u_string, "THIS IS DEMONSTRATION OF GitHub CONCEPT"]]);

// Accessing values from the Map
console.log(myMap.get(u_string));

// OTHER STUFF
// docker --version
// node script.js
// docker build -t docker .
// docker images
// docker pull node         # openjdk
// docker run --name container1 -it -d node
// docker ps
// docker exec -it container1 node         #script.js

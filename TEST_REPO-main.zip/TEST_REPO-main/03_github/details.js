console.log("hello from roshan");
// git init
// git add .
// git commit -m "[050524-0844P]"
// git remote add origin https://<t>/<u&rb>
// git push -u origin main

// OTHER STUFF:-

// git config --list
// git config user.email
// git config user.name
// git config --unset user.name
// git config --unset user.email
// git config --global user.email "your-email@example.com"
// git config --global user.name "Your Name"

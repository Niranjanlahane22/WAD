// Create a folder "assgn2c"
// Open New Terminal
// npm install -g @angular/cli @latest
// ng new part-c
// if error, open termial in vs code and type the cmd: "Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass"

// ----------------------------------------------------------------------------------------------------------

// Step 1: Do Exam login.
// step 2: Create a folder "assgn2c".
// Step 3: Open Vs code.
// Step 4: Open the "assgn2c" folder in VS code
// Step 5: Open New Terminal
// Step 6: run the following command to install angular
// "npm install -g @angular/cli @latest"
// Step7: If succesfull the create a new angular project using cmd
// "ng new part-c"
// Step 8: if Step 6 is not working then :
// Step 9: Open C drive
// Step 10: search for the "angular' folder
// Step 11: copy the path:
// "C:\Users\exam\AppData\Roaming\npm\node_modules\@angular\cli\node_modules\@schema
// tics\angular"
// Step 12: open Windows powershell as Administrator
// Step 13: type cd
// "C:\Users\exam\AppData\Roaming\npm\node_modules\@angular\cli\node_modules\@schematics\ang
// ular"
// Step 14: change the Execution Policy by typing the command:
// "Set-ExecutionPolicy RemoteSigned"
// Step 15: select yes by typing y/Y
// step 16: continue with Step 7
// step 17: if still getting the error, open termial in vs code and type the cmd:
// "Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass"
// Step 18 : continue with step 7.

// index.js
// public
//    ---index.html

// terminal:-
// npm init
// npm install express
// node index.js

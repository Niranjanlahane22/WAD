// index.js
// mongodb.js

// --------------------------------------------------------------------------------------------------------

// create database & collection:-
// database:- student
// collection:- profile

// add data in the format:-

//             {
//                 "_id": {
//                 "$oid": "6621341182fcef8dec3f9d5a"
//                 },
//                 "name": "roshan",
//                 "email": "roshan@gmail.com",
//                 "location": "nashik"
//             }

// --------------------------------------------------------------------------------------------------------

// npm init
// npm install express
// npm install mongodb
// node index.js
